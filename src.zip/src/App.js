// import logo from './logo.svg';
import './App.css';
import Complete from './components/Complete';

function App() {
  return (
    <>
    <Complete/>
    </>
    );
}

export default App;
